__all__ = ["CLIENT", "CURSOR", "FIELD_TYPE", "FIELD_FLAG",
           "INDICATOR", 'STATUS', 'ERR', 'CAPABILITY']
